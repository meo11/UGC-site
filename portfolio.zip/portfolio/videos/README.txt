HOW TO ADD A VIDEO TO YOUR PORTFOLIO
=====================================

1. Drop your MP4 file into this /videos folder. Suggested filenames:
     - tech-1.mp4 / tech-2.mp4
     - fitness-ag1.mp4 / fitness-gymshark.mp4
     - food-oikos.mp4 / food-larq.mp4
     - home-lysol.mp4 / home-cetaphil.mp4

2. Open index.html, find the matching <div class="video-card"> for that slot.

3. Replace the placeholder content with a real video. Example:

   BEFORE (placeholder):
   <div class="video-card">
     <div class="video-card-tag">Spec Ad / 07</div>
     <div class="video-card-product">...</div>
     <div class="video-card-play">▶</div>
   </div>

   AFTER (real video):
   <div class="video-card">
     <video controls preload="metadata" playsinline>
       <source src="videos/home-lysol.mp4" type="video/mp4">
     </video>
   </div>

4. Save, refresh. Done.

TIPS:
- Keep videos under 15MB each so the site loads fast.
- Compress with HandBrake (free): "Web Optimized" preset, 1080p, 5 Mbps.
- 9:16 aspect ratio works best (your TikTok/Reels exports are already this).
